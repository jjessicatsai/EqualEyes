document.getElementById("darkMode").addEventListener("change", function(e) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "darkMode" });
  });
});

document.getElementById("highContrast").addEventListener("change", function(e) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "highContrast" });
  });
});

document.getElementById("smartContrast").addEventListener("change", function(e) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "smartContrast" });
  });
});

document.getElementById("enlargenText").addEventListener("change", function(e) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "enlargenText" });
  });
});

document.getElementById("increaseSpacing").addEventListener("change", function(e) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "increaseSpacing" });
  });
});