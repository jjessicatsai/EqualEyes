// Apply saved settings when page loads
chrome.storage.local.get(['darkMode', 'highContrast', 'smartContrast', 'enlargenText', 'increaseSpacing'], function(result) {
  if (result.darkMode) darkMode();
  if (result.highContrast) highContrast();
  if (result.smartContrast) smartContrast();
  if (result.enlargenText) enlargenText();
  if (result.increaseSpacing) increaseSpacing();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "clearContrast") {
    clearContrast();
  }
  if (msg.action === "darkMode") {
    darkMode();
  }
  if (msg.action === "highContrast") {
    highContrast();   
  }
  if (msg.action === "smartContrast") {
    smartContrast();
  }
  if (msg.action === "enlargenText") {
    enlargenText();
  }
  if (msg.action === "increaseSpacing") {
    increaseSpacing();
  }
});

// New function to clear all contrast modes
function clearContrast() {
  // Remove dark mode
  const darkModeStyle = document.getElementById('dark-mode-style');
  if (darkModeStyle) darkModeStyle.remove();
  
  // Remove high contrast
  const highContrastStyle = document.getElementById('high-contrast-style');
  if (highContrastStyle) highContrastStyle.remove();
  
  // Remove smart contrast
  const smartContrastElements = document.querySelectorAll('[data-smart-applied="true"]');
  smartContrastElements.forEach(el => {
    el.style.color = el.dataset.originalColor || '';
    delete el.dataset.smartApplied;
    delete el.dataset.originalColor;
  });
}
 
function darkMode() {
  const styleId = 'dark-mode-style';
  const existing = document.getElementById(styleId);

  if (existing) {
    existing.remove();
    console.log("Dark mode removed!");
    return;
  }

  const style = document.createElement("style");
  style.id = styleId;

  style.innerHTML = `
    body, 
    article, section, main, aside, header, footer,
    div:not([role="button"]),
    p, span, li, ul, ol, table, tbody, tr, td, th,
    h1, h2, h3, h4, h5, h6 {
      background-color: #202124 !important;
      color: #e5e5e5 !important;
    }

    /* Optional: make images look natural */
    img {
      background-color: transparent !important;
    }
  `;

  document.head.appendChild(style);
  console.log("Dark mode applied!");
}


function highContrast() {
  const styleId = 'high-contrast-style';
  const existing = document.getElementById(styleId);

  if (existing) {
    existing.remove();
    console.log("High contrast mode removed!");
    return;
  }

  const style = document.createElement("style");
  style.id = styleId;

  style.innerHTML = `
    body, 
    article, section, main, aside, header, footer,
    div:not([role="button"]),
    p, span, li, ul, ol, table, tbody, tr, td, th,
    h1, h2, h3, h4, h5, h6 {
      background-color: black !important;
      color: white !important;
    }

    /* Optional: make images look natural */
    img {
      background-color: transparent !important;
    }
  `;

  document.head.appendChild(style);
  console.log("High contrast mode applied!");
}

function smartContrast() {
  const textElements = document.querySelectorAll(
    "p, span, h1, h2, h3, h4, h5, h6, li, td, div, button, label, input, textarea"
  );

  // Check if any element has smart contrast applied to determine toggle state
  const isApplied = document.querySelector('[data-smart-applied="true"]');

  textElements.forEach(el => {
    if (isApplied) {
      // Toggle OFF: restore original color
      if (el.dataset.smartApplied === 'true') {
        el.style.color = el.dataset.originalColor || '';
        delete el.dataset.smartApplied;
        delete el.dataset.originalColor;
      }
    } else {
      // Toggle ON: apply smart contrast
      // Store original color for toggle
      el.dataset.originalColor = window.getComputedStyle(el).color;

      // Get nearest solid background
      let bg = getActualBackground(el);

      // Convert to RGB
      const rgb = bg.match(/\d+/g)?.map(Number) || [255, 255, 255];

      // Compute luminance using relative luminance formula
      const luminance = 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];

      // Apply white text on dark backgrounds, black text on light backgrounds
      el.style.setProperty('color', luminance < 128 ? 'white' : 'black', 'important');
      el.dataset.smartApplied = 'true';
    }
  });

  console.log(isApplied ? "Smart contrast removed!" : "Smart contrast applied!");
}

// Helper: traverse up DOM to find first solid background
function getActualBackground(el) {
  while (el) {
    const bg = window.getComputedStyle(el).backgroundColor;
    if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') return bg;
    el = el.parentElement;
  }
  return 'rgb(255, 255, 255)'; // fallback
}

function enlargenText() {
  const styleId = 'enlarge-text-style';
  const existing = document.getElementById(styleId);

  if (existing) {
    // Toggle OFF: restore original sizes
    const enlargedElements = document.querySelectorAll('[data-enlarged-text="true"]');
    enlargedElements.forEach(el => {
      el.style.fontSize = el.dataset.originalFontSize || '';
      delete el.dataset.enlargedText;
      delete el.dataset.originalFontSize;
    });
    existing.remove();
    console.log("Text enlargement removed!");
    return;
  }

  // Find all text elements with font size less than 16px
  const allElements = document.querySelectorAll('*');
  
  allElements.forEach(el => {
    const fontSize = parseFloat(window.getComputedStyle(el).fontSize);
    
    if (fontSize < 16) {
      // Store original size for toggle
      el.dataset.originalFontSize = el.style.fontSize || '';
      el.style.setProperty('font-size', '16px', 'important');
      el.dataset.enlargedText = 'true';
    }
  });

  // Create a marker element so we know enlargement is active
  const marker = document.createElement('div');
  marker.id = styleId;
  marker.style.display = 'none';
  document.body.appendChild(marker);

  console.log("Text enlarged to minimum 16px!");
}

function increaseSpacing() {
  const styleId = 'increase-spacing-style';
  const existing = document.getElementById(styleId);

  if (existing) {
    const spacedElements = document.querySelectorAll('[data-spacing-applied="true"]');
    spacedElements.forEach(el => {
      el.style.lineHeight = el.dataset.originalLineHeight || '';
      delete el.dataset.spacingApplied;
      delete el.dataset.originalLineHeight;
    });
    existing.remove();
    console.log("Line spacing removed!");
    return;
  }

  // find all elements and only change those with line-height < 1.5
  const textElements = document.querySelectorAll('p, li, div, span, td, th, blockquote, article');
  
  textElements.forEach(el => {
    const computedStyle = window.getComputedStyle(el);
    const fontSize = parseFloat(computedStyle.fontSize);
    const lineHeight = parseFloat(computedStyle.lineHeight);
    
    // calculate current line-height ratio
    const ratio = lineHeight / fontSize;
    
    if (ratio < 1.5) {
      // store original for toggle
      el.dataset.originalLineHeight = el.style.lineHeight || '';
      el.style.setProperty('line-height', '1.5em', 'important');
      el.dataset.spacingApplied = 'true';
    }
  });

  // Create a marker element
  const marker = document.createElement('div');
  marker.id = styleId;
  marker.style.display = 'none';
  document.body.appendChild(marker);

  console.log("Line spacing increased to 1.5x font size where needed!");
}