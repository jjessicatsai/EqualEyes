// Dark Mode
document.getElementById("darkMode").addEventListener("change", function(e) {
  const isChecked = e.target.checked;
  
  if (isChecked) {
    // Turn off other contrast modes
    document.getElementById('highContrast').checked = false;
    document.getElementById('smartContrast').checked = false;
    chrome.storage.local.set({ darkMode: true, highContrast: false, smartContrast: false });
    
    // Turn off other modes in the page
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, { action: "clearContrast" });
      chrome.tabs.sendMessage(tabs[0].id, { action: "darkMode" });
    });
  } else {
    chrome.storage.local.set({ darkMode: false });
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, { action: "darkMode" });
    });
  }
});

// High Contrast
document.getElementById("highContrast").addEventListener("change", function(e) {
  const isChecked = e.target.checked;
  
  if (isChecked) {
    // Turn off other contrast modes
    document.getElementById('darkMode').checked = false;
    document.getElementById('smartContrast').checked = false;
    chrome.storage.local.set({ darkMode: false, highContrast: true, smartContrast: false });
    
    // Turn off other modes in the page
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, { action: "clearContrast" });
      chrome.tabs.sendMessage(tabs[0].id, { action: "highContrast" });
    });
  } else {
    chrome.storage.local.set({ highContrast: false });
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, { action: "highContrast" });
    });
  }
});

// Smart Contrast
document.getElementById("smartContrast").addEventListener("change", function(e) {
  const isChecked = e.target.checked;
  
  if (isChecked) {
    // Turn off other contrast modes
    document.getElementById('darkMode').checked = false;
    document.getElementById('highContrast').checked = false;
    chrome.storage.local.set({ darkMode: false, highContrast: false, smartContrast: true });
    
    // Turn off other modes in the page
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, { action: "clearContrast" });
      chrome.tabs.sendMessage(tabs[0].id, { action: "smartContrast" });
    });
  } else {
    chrome.storage.local.set({ smartContrast: false });
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, { action: "smartContrast" });
    });
  }
});

// Enlarge Text (unchanged)
document.getElementById("enlargenText").addEventListener("change", function(e) {
  const isChecked = e.target.checked;
  chrome.storage.local.set({ enlargenText: isChecked });
  
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "enlargenText" });
  });
});

// Increase Spacing (unchanged)
document.getElementById("increaseSpacing").addEventListener("change", function(e) {
  const isChecked = e.target.checked;
  chrome.storage.local.set({ increaseSpacing: isChecked });
  
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "increaseSpacing" });
  });
});

// Load saved states when popup opens
document.addEventListener('DOMContentLoaded', function() {
  chrome.storage.local.get(['darkMode', 'highContrast', 'smartContrast', 'enlargenText', 'increaseSpacing'], function(result) {
    if (result.darkMode) document.getElementById('darkMode').checked = true;
    if (result.highContrast) document.getElementById('highContrast').checked = true;
    if (result.smartContrast) document.getElementById('smartContrast').checked = true;
    if (result.enlargenText) document.getElementById('enlargenText').checked = true;
    if (result.increaseSpacing) document.getElementById('increaseSpacing').checked = true;
  });
});